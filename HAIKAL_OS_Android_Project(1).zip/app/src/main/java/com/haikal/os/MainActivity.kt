package com.haikal.os

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.pm.PackageManager

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 10, 18)
    private val panel = Color.rgb(17, 24, 39)
    private val blue = Color.rgb(0, 190, 255)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var allApps: List<android.content.pm.ResolveInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        allApps = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 5, 0, 5)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            isAllCaps = false
            background = rounded(Color.rgb(20, 54, 78), 18f)
            setOnClickListener { action() }
        }

    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(20, 18, 20, 18)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("HAIKAL OS", 20f, blue, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⌂ Home") { showHome() })
        root.addView(header)
        root.addView(text(title, 13f, Color.LTGRAY))
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 18)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        nav.addView(button("Home") { showHome() }, LinearLayout.LayoutParams(0, 52, 1f))
        nav.addView(button("Apps") { showApps("") }, LinearLayout.LayoutParams(0, 52, 1f))
        nav.addView(button("Game Hub") { showGames() }, LinearLayout.LayoutParams(0, 52, 1f))
        nav.addView(button("Tools") { showTools() }, LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(nav)
        setContentView(root)
    }

    private fun card(title: String, subtitle: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel)
            setPadding(16, 14, 16, 14)
        }
        box.addView(text(title, 17f, blue, true))
        box.addView(text(subtitle, 13f, Color.LTGRAY))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 12
        content.addView(box, lp)
    }

    private fun showHome() {
        setup("Gaming launcher • Version 1.0")
        val hour = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        val date = java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault()).format(java.util.Date())
        content.addView(text(hour, 54f, Color.WHITE, true))
        content.addView(text(date, 15f, Color.LTGRAY))
        card("WELCOME BACK", "Your space. Your games. Your HAIKAL OS.")
        card("GAME HUB", "Your installed games in one place.")
        content.addView(button("OPEN GAME HUB") { showGames() }, LinearLayout.LayoutParams(-1, 54))
        card("HAIKAL MUSIC", "Open your offline music player from the Apps page.")
        content.addView(button("VIEW ALL APPS") { showApps("") }, LinearLayout.LayoutParams(-1, 54))
        card("NEON BLUE • GAMING MODE", "A clean dark interface inspired by gaming phones.")
    }

    private fun showApps(filter: String) {
        setup("APP DRAWER")
        val search = EditText(this).apply {
            hint = "Search apps..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            background = rounded(panel)
            setPadding(16, 12, 16, 12)
            setText(filter)
        }
        content.addView(search, LinearLayout.LayoutParams(-1, 54))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        fun populate(query: String) {
            list.removeAllViews()
            allApps.filter { it.loadLabel(packageManager).toString().contains(query, true) }
                .forEach { info ->
                    val name = info.loadLabel(packageManager).toString()
                    val row = button("  ${info.loadIcon(packageManager).let { name }}") {
                        try {
                            val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                            if (launch != null) startActivity(launch)
                        } catch (_: Exception) {
                            Toast.makeText(this, "Cannot open app", Toast.LENGTH_SHORT).show()
                        }
                    }
                    row.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    val lp = LinearLayout.LayoutParams(-1, 54)
                    lp.topMargin = 6
                    list.addView(row, lp)
                }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        populate(filter)
    }

    private fun showGames() {
        setup("GAME HUB")
        card("MY GAMES", "Games installed on your phone.")
        val games = allApps.filter {
            val n = it.loadLabel(packageManager).toString().lowercase()
            listOf("mobile legends", "pubg", "free fire", "genshin", "roblox", "minecraft", "hok").any { key -> n.contains(key) }
        }
        if (games.isEmpty()) {
            content.addView(text("No recognised games found yet. Open Apps to launch any game.", 14f, Color.LTGRAY))
        } else games.forEach {
            val name = it.loadLabel(packageManager).toString()
            content.addView(button("🎮  $name") {
                packageManager.getLaunchIntentForPackage(it.activityInfo.packageName)?.let { intent -> startActivity(intent) }
            }, LinearLayout.LayoutParams(-1, 54))
        }
        content.addView(button("ALL APPS") { showApps("") }, LinearLayout.LayoutParams(-1, 54))
    }

    private fun showTools() {
        setup("TOOLS & SHORTCUTS")
        card("QUICK ACCESS", "These shortcuts open Android's real settings pages.")
        content.addView(button("Android Settings") {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        }, LinearLayout.LayoutParams(-1, 54))
        content.addView(button("Display Settings") {
            startActivity(Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS))
        }, LinearLayout.LayoutParams(-1, 54))
        content.addView(button("Sound Settings") {
            startActivity(Intent(android.provider.Settings.ACTION_SOUND_SETTINGS))
        }, LinearLayout.LayoutParams(-1, 54))
        content.addView(button("Wallpaper & Style") {
            try { startActivity(Intent("android.settings.WALLPAPER_SETTINGS")) }
            catch (_: Exception) { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        }, LinearLayout.LayoutParams(-1, 54))
        card("NOTE", "HAIKAL OS is a launcher app. Android's system notification shade and hardware performance controls remain managed by your phone.")
    }
}
