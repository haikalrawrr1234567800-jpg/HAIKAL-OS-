# HAIKAL OS — RedMagic Edition

A real Android home-screen launcher starter project, designed for portrait phones with a dark neon-blue gaming interface.

## Features
- Set HAIKAL OS as the Android Home app
- Home screen with clock, quick access tiles and HAIKAL MUSIC shortcut
- App drawer with live search and launch installed apps
- Game Hub that lists installed games based on app names
- In-app Control Center shortcuts to Android Wi-Fi, Bluetooth, display, sound, battery and system settings

## Build APK without Android Studio
1. Create a GitHub repository and upload the contents of this ZIP.
2. Open the **Actions** tab and run **Build HAIKAL OS APK** (or push to main/master).
3. Download the **HAIKAL-OS-APK** artifact from the completed workflow.
4. Extract `app-debug.apk` and install it on your Android phone.
5. Press Home and choose **HAIKAL OS** as the default launcher.

## Notes
This is a launcher app, not a replacement Android operating system. Android's real notification shade and Quick Settings remain controlled by the phone system; the Control Center here provides shortcuts into Android settings. The app list and Game Hub use apps installed on the device.
