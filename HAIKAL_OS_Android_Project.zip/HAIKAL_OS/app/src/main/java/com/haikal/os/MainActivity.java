package com.haikal.os;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(7,12,23), PANEL=Color.rgb(14,24,42), BLUE=Color.rgb(24,190,255), WHITE=Color.WHITE, MUTED=Color.rgb(150,174,198);
    private LinearLayout root; private ArrayList<AppInfo> apps=new ArrayList<>(); private boolean drawer=false;
    static class AppInfo { String label; String pkg; android.graphics.drawable.Drawable icon; AppInfo(String l,String p,android.graphics.drawable.Drawable i){label=l;pkg=p;icon=i;} }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);loadApps();showHome();}
    private void loadApps(){apps.clear();PackageManager pm=getPackageManager();Intent i=new Intent(Intent.ACTION_MAIN,null);i.addCategory(Intent.CATEGORY_LAUNCHER);for(ResolveInfo r:pm.queryIntentActivities(i,0)){String p=r.activityInfo.packageName;if(p.equals(getPackageName()))continue;apps.add(new AppInfo(r.loadLabel(pm).toString(),p,r.loadIcon(pm)));}Collections.sort(apps,(a,b)->a.label.compareToIgnoreCase(b.label));}
    private GradientDrawable shape(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(20));if(stroke>0)d.setStroke(dp(1),stroke);return d;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void base(){root=column();root.setPadding(dp(20),dp(18),dp(20),dp(18));root.setBackgroundColor(BG);setContentView(root);}
    private void showHome(){drawer=false;base();LinearLayout top=row();TextView brand=text("HAIKAL  /  OS",17,WHITE,true);top.addView(brand,new LinearLayout.LayoutParams(0,dp(40),1));TextView ver=text("V1.0  •  GAMING",10,BLUE,true);top.addView(ver);root.addView(top);
        TextView date=text(new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date()).toUpperCase(Locale.getDefault()),11,MUTED,true);date.setPadding(0,dp(24),0,dp(5));root.addView(date);
        TextView clock=text(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),58,WHITE,true);root.addView(clock);
        TextView tagline=text("LEVEL UP YOUR EVERYDAY",11,BLUE,true);tagline.setPadding(0,0,0,dp(18));root.addView(tagline);
        LinearLayout hero=column();hero.setPadding(dp(18),dp(18),dp(18),dp(18));hero.setBackground(shape(PANEL,Color.rgb(22,105,160)));TextView h=text("GAMING CENTER",11,BLUE,true);hero.addView(h);TextView ht=text("READY FOR\nTHE NEXT MATCH?",23,WHITE,true);ht.setPadding(0,dp(8),0,dp(12));hero.addView(ht);TextView sub=text("Your games. Your space. Your rules.",12,MUTED,false);hero.addView(sub);root.addView(hero,lp(-1,150));
        TextView quick=text("QUICK ACCESS",11,MUTED,true);quick.setPadding(0,dp(22),0,dp(10));root.addView(quick);
        LinearLayout grid=row();grid.setGravity(Gravity.CENTER);String[] names={"APPS","GAME HUB","CONTROL","SETTINGS"};String[] icons={"▦","◈","☷","⚙"};for(int n=0;n<4;n++){final int k=n;LinearLayout tile=column();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(12),dp(5),dp(12));tile.setBackground(shape(PANEL,0));TextView ic=text(icons[n],25,BLUE,true);ic.setGravity(Gravity.CENTER);tile.addView(ic);TextView tx=text(names[n],9,WHITE,true);tx.setGravity(Gravity.CENTER);tx.setPadding(0,dp(7),0,0);tile.addView(tx);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(92),1);p.setMargins(dp(3),0,dp(3),0);grid.addView(tile,p);tile.setOnClickListener(v->{if(k==0)showDrawer();else if(k==1)showGames();else if(k==2)showControl();else openSettings();});}root.addView(grid);
        TextView music=text("♫   HAIKAL MUSIC",15,WHITE,true);music.setPadding(dp(16),dp(16),dp(16),dp(16));music.setBackground(shape(PANEL,0));LinearLayout.LayoutParams mp=lp(-1,58);mp.topMargin=dp(16);root.addView(music,mp);music.setOnClickListener(v->launchByName("HAIKAL MUSIC"));
        View spacer=new View(this);root.addView(spacer,new LinearLayout.LayoutParams(1,0,1));TextView dock=text("PHONE     MESSAGES     CAMERA     BROWSER",10,MUTED,true);dock.setGravity(Gravity.CENTER);dock.setPadding(0,dp(12),0,dp(8));root.addView(dock);TextView hint=text("Swipe down for Android notifications  •  Tap APPS to explore",9,MUTED,false);hint.setGravity(Gravity.CENTER);root.addView(hint);
    }
    private void showDrawer(){drawer=true;base();LinearLayout top=row();TextView title=text("ALL APPLICATIONS",18,WHITE,true);top.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));TextView back=text("HOME",11,BLUE,true);top.addView(back);back.setOnClickListener(v->showHome());root.addView(top);EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Search apps...");search.setHintTextColor(MUTED);search.setTextColor(WHITE);search.setPadding(dp(14),0,dp(14),0);search.setBackground(shape(PANEL,Color.rgb(30,80,120)));root.addView(search,lp(-1,48));ScrollView sc=new ScrollView(this);LinearLayout list=column();list.setPadding(0,dp(10),0,0);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));populate(list,"");search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){populate(list,s.toString());}public void afterTextChanged(Editable e){}});}
    private void populate(LinearLayout list,String q){list.removeAllViews();for(AppInfo a:apps){if(!a.label.toLowerCase().contains(q.toLowerCase()))continue;LinearLayout r=row();r.setPadding(dp(10),dp(8),dp(10),dp(8));ImageView iv=new ImageView(this);iv.setImageDrawable(a.icon);r.addView(iv,lp(42,42));TextView name=text(a.label,15,WHITE,true);name.setPadding(dp(14),0,0,0);r.addView(name);list.addView(r,lp(-1,58));r.setOnClickListener(v->launch(a.pkg));}}
    private void showGames(){base();header("GAME HUB");TextView t=text("YOUR BATTLE STATION",25,WHITE,true);t.setPadding(0,dp(20),0,dp(8));root.addView(t);root.addView(text("Games installed on your phone appear here.",12,MUTED,false));ScrollView sc=new ScrollView(this);LinearLayout l=column();sc.addView(l);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));for(AppInfo a:apps){if(a.label.toLowerCase().matches(".*(game|legends|pubg|free fire|genshin|roblox|minecraft|cod).*")){LinearLayout r=row();ImageView im=new ImageView(this);im.setImageDrawable(a.icon);r.addView(im,lp(40,40));TextView nm=text(a.label,15,WHITE,true);nm.setPadding(dp(12),0,0,0);r.addView(nm);l.addView(r,lp(-1,60));r.setOnClickListener(v->launch(a.pkg));}}button("OPEN APP DRAWER",()->showDrawer());}
    private void showControl(){base();header("CONTROL CENTER");TextView t=text("DEVICE SHORTCUTS",12,MUTED,true);t.setPadding(0,dp(20),0,dp(12));root.addView(t);button("Wi-Fi & Network Settings",()->startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)));button("Bluetooth Settings",()->startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)));button("Display & Brightness",()->startActivity(new Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS)));button("Sound Settings",()->startActivity(new Intent(android.provider.Settings.ACTION_SOUND_SETTINGS)));button("Battery Settings",()->startActivity(new Intent(Intent.ACTION_POWER_USAGE_SUMMARY)));button("Android System Settings",()->openSettings());}
    private void header(String s){LinearLayout r=row();TextView b=text("‹  HOME",12,BLUE,true);r.addView(b);b.setOnClickListener(v->showHome());TextView t=text("     "+s,16,WHITE,true);r.addView(t);root.addView(r,lp(-1,45));}
    private void button(String s,Runnable action){TextView b=text(s,14,WHITE,true);b.setPadding(dp(16),dp(16),dp(16),dp(16));b.setBackground(shape(PANEL,0));LinearLayout.LayoutParams p=lp(-1,56);p.topMargin=dp(9);root.addView(b,p);b.setOnClickListener(v->action.run());}
    private void openSettings(){try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){}}
    private void launch(String pkg){Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);}
    private void launchByName(String name){for(AppInfo a:apps)if(a.label.toLowerCase().contains(name.toLowerCase())){launch(a.pkg);return;}Toast.makeText(this,"Install HAIKAL MUSIC to open it here",Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(drawer)showHome();else super.onBackPressed();}
}
